<?php

namespace App\Models\Backend\Website;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    //
}

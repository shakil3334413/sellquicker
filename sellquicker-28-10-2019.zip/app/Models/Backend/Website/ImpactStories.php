<?php

namespace App\Models\Backend\Website;

use Illuminate\Database\Eloquent\Model;

class ImpactStories extends Model
{
    //
}

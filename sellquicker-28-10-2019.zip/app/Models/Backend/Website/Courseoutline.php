<?php

namespace App\Models\Backend\Website;

use Illuminate\Database\Eloquent\Model;

class Courseoutline extends Model
{
    //
}

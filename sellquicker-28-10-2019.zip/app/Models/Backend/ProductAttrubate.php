<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class ProductAttrubate extends Model
{
    //
}

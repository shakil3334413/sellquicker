<?php

namespace App\Models\Frontend;

use Illuminate\Database\Eloquent\Model;

class SellService extends Model
{
    //
}

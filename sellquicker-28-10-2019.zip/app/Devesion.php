<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Devesion extends Model
{
    //
}

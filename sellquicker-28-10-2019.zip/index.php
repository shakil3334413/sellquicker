<?php
 header("Location: public/");
?>
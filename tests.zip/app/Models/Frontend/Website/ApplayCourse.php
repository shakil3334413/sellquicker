<?php

namespace App\Models\Frontend\Website;

use Illuminate\Database\Eloquent\Model;

class ApplayCourse extends Model
{
    //
}

<?php

namespace App\Models\Frontend;

use Illuminate\Database\Eloquent\Model;

class BannerAdsPagePositionRequest extends Model
{
    //
}
